from django.apps import AppConfig


class Nim1AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nim1app'
